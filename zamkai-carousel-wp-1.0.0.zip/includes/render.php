<?php

    require_once plugin_dir_path(__FILE__) . '../tg-carousel.php';

    echo do_shortcode('[youtube_playlist_grid]');

?>