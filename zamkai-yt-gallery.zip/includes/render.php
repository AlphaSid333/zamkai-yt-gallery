<?php

	require_once plugin_dir_path( __FILE__ ) . '../zamkai-yt-gallery.php';

	echo do_shortcode( '[youtube_playlist_grid]' );
